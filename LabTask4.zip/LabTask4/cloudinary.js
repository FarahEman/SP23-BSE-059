

const cloudinary = require("cloudinary").v2;

cloudinary.config({
  cloud_name: "dlalsbdhl",
  api_key: "423222291868687",
  api_secret: "5J2Z06G15LmCfN-yeURcKQhaO6k",
});

module.exports = cloudinary;

